#include <stdio.h>

int suma(int a, int b) {
    return a + b;
}

int main() {
    int a=5, b=10, c;

    c = suma(a, b);

    return 0;
}
